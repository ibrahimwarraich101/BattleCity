import pygame
import sys
import random
import math
import asyncio
from constants import *
from game_map import GameMap
from tank import PlayerTank, EnemyTank, BossTank
from hud import HUD

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Battle City - AI Combat Evolved")
        self.clock = pygame.time.Clock()
        self.hud = HUD()
        
        self.level = 1
        self.debug_mode = False
        self.game_state = "MENU"
        self.splash_timer = 0
        self.boss_log_saved = False
        self.total_stats = []
        self.player = None
        self.enemies = []
        self.bullets = []
        self.frame_count = 0
        self.game_map = None
        
        # UI State
        self.menu_selection = 0
        self.menu_options = [
            {"id": 1, "name": "STAGE 1", "desc": "The Frontlines", "color": COLOR_PLAYER},
            {"id": 2, "name": "STAGE 2", "desc": "Industrial Zone", "color": COLOR_ENEMY_ARMOR},
            {"id": 'B', "name": "BOSS FIGHT", "desc": "Ultimate AI Challenge", "color": COLOR_BOSS_P3},
            {"id": 'H', "name": "HOW TO PLAY", "desc": "Controls & Tactics", "color": COLOR_ACCENT}
        ]
        
        # Mobile Controls State
        self.is_mobile = False 
        self.dpad_rects = {
            UP: pygame.Rect(80, SCREEN_HEIGHT - 160, 60, 60),
            DOWN: pygame.Rect(80, SCREEN_HEIGHT - 60, 60, 60),
            LEFT: pygame.Rect(20, SCREEN_HEIGHT - 110, 60, 60),
            RIGHT: pygame.Rect(140, SCREEN_HEIGHT - 110, 60, 60)
        }
        self.fire_rect = pygame.Rect(SCREEN_WIDTH - 120, SCREEN_HEIGHT - 120, 80, 80)

    def reset_level(self):
        self.game_map = GameMap(self.level)
        
        if self.level == 'B':
            self.player = PlayerTank(BOSS_PLAYER_SPAWN[0], BOSS_PLAYER_SPAWN[1])
            self.enemies = [BossTank(BOSS_SPAWN[0], BOSS_SPAWN[1])]
            self.enemy_pool = []
            self.game_state = "BOSS_FIGHT"
        else:
            self.player = PlayerTank(PLAYER_SPAWN[0], PLAYER_SPAWN[1])
            self.enemies = []
            self.game_state = "PLAYING"
        
        self.bullets = []
        self.frame_count = 0
        self.spawn_timer = 0
        self.spawn_index = 0
        self.enemies_killed = 0
        self.boss_log_saved = False
        
        if self.level == 1:
            self.enemy_pool = ['basic']*7 + ['fast']*5
        elif self.level == 2:
            self.enemy_pool = ['fast']*4 + ['armor']*3 + ['power']*2
        elif self.level == 'B':
            self.enemy_pool = []
        else:
            self.enemy_pool = ['basic']*10

    def handle_input(self):
        if self.game_state not in ["PLAYING", "BOSS_FIGHT"] or self.player is None:
            return

        keys = pygame.key.get_pressed()
        moved = False
        
        if self.player.active:
            # Keyboard Check
            if keys[pygame.K_UP] or keys[pygame.K_w]:
                self.player.move(UP, self.game_map, self.enemies + [self.player]); moved = True
            elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
                self.player.move(DOWN, self.game_map, self.enemies + [self.player]); moved = True
            elif keys[pygame.K_LEFT] or keys[pygame.K_a]:
                self.player.move(LEFT, self.game_map, self.enemies + [self.player]); moved = True
            elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                self.player.move(RIGHT, self.game_map, self.enemies + [self.player]); moved = True
            
            if keys[pygame.K_SPACE]:
                self.player.shoot(self.bullets)

            # Touch Check (Mobile)
            if not moved and pygame.mouse.get_pressed()[0]:
                mx, my = pygame.mouse.get_pos()
                for direction, rect in self.dpad_rects.items():
                    if rect.collidepoint(mx, my):
                        self.is_mobile = True
                        self.player.move(direction, self.game_map, self.enemies + [self.player])
                
                if self.fire_rect.collidepoint(mx, my):
                    self.is_mobile = True
                    self.player.shoot(self.bullets)

    def handle_menu_click(self, pos):
        card_w, card_h = 400, 70
        start_y = 220
        for i, opt in enumerate(self.menu_options):
            y_pos = start_y + i * (card_h + 15)
            rect = pygame.Rect(SCREEN_WIDTH // 2 - card_w // 2, y_pos, card_w, card_h)
            if rect.collidepoint(pos):
                if self.menu_selection == i:
                    self.process_selection(opt['id'])
                else:
                    self.menu_selection = i
                return True
        return False

    def process_selection(self, selection_id):
        if selection_id == 'H':
            self.game_state = "HOW_TO"
        else:
            self.start_splash(selection_id)

    def update(self):
        if self.game_state == "SPLASH":
            self.splash_timer -= 1
            if self.splash_timer <= 0:
                self.reset_level()
            return

        if self.game_state not in ["PLAYING", "BOSS_FIGHT"]:
            return

        if not self.player.active and self.player.lives > 0:
            self.player.respawn_timer -= 1
            if self.player.respawn_timer <= 0:
                self.player.respawn()
                if self.level == 'B':
                    self.player.x, self.player.y = BOSS_PLAYER_SPAWN
        
        self.player.update()

        for enemy in self.enemies:
            if enemy.active:
                enemy.update_ai(self.game_map, self.enemies + [self.player], self.bullets, self.player)

        for bullet in self.bullets[:]:
            if bullet.active:
                bullet.update(self.game_map, self.enemies + [self.player], self.bullets, self.frame_count)
            else:
                self.bullets.remove(bullet)

        for enemy in self.enemies[:]:
            if not enemy.active:
                self.enemies.remove(enemy)
                self.enemies_killed += 1

        if not self.debug_mode:
            if len(self.enemies) < MAX_ACTIVE_ENEMIES and len(self.enemy_pool) > 0:
                self.spawn_timer += 1
                if self.spawn_timer >= FPS * 2:
                    spawn_pos = ENEMY_SPAWNS[self.spawn_index]
                    if abs(spawn_pos[0] - self.player.x) + abs(spawn_pos[1] - self.player.y) > 10:
                        type = self.enemy_pool.pop(0)
                        self.enemies.append(EnemyTank(spawn_pos[0], spawn_pos[1], type))
                        self.spawn_index = (self.spawn_index + 1) % len(ENEMY_SPAWNS)
                        self.spawn_timer = 0

        if self.level != 'B':
            if self.game_map.get_tile(EAGLE_POS[0], EAGLE_POS[1]) != EAGLE:
                self.game_state = "GAME_OVER"
            elif self.player.lives <= 0 and not self.player.active:
                self.game_state = "GAME_OVER"
            elif len(self.enemy_pool) == 0 and len(self.enemies) == 0:
                self.game_state = "STAGE_CLEAR"
        else:
            if self.player.lives <= 0 and not self.player.active:
                self.game_state = "GAME_OVER"
            elif len(self.enemies) == 0:
                self.game_state = "VICTORY"
                if not self.boss_log_saved:
                    self.save_boss_stats()

    def save_boss_stats(self):
        try:
            with open("boss_stats.txt", "w") as f:
                f.write("BATTLE CITY - BOSS FIGHT LOG\n")
                f.write("----------------------------\n")
                for i, stats in enumerate(self.total_stats):
                    f.write(f"Tick {i}: Raw={stats[0]}, Pruned={stats[1]}, Speedup={stats[0]/stats[1]:.2f}x\n")
            self.boss_log_saved = True
        except: pass

    def start_splash(self, level):
        self.level = level
        self.game_state = "SPLASH"
        self.splash_timer = STAGE_SPLASH_TIME

    def toggle_debug(self):
        self.debug_mode = not self.debug_mode
        if self.debug_mode:
            self.level = 1
            self.reset_level()
            for y in range(5, 10): self.game_map.set_tile(6, y, BRICK)
            self.enemies = [EnemyTank(0,0,'basic'), EnemyTank(12,0,'fast'), EnemyTank(24,0,'armor')]
            self.enemy_pool = []
        else: self.reset_level()

    async def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.game_state == "MENU":
                        self.handle_menu_click(event.pos)
                    elif self.game_state in ["STAGE_CLEAR", "GAME_OVER", "VICTORY", "HOW_TO"]:
                        self.game_state = "MENU"
                
                if event.type == pygame.KEYDOWN:
                    if self.game_state == "MENU":
                        if event.key in [pygame.K_UP, pygame.K_w]:
                            self.menu_selection = (self.menu_selection - 1) % len(self.menu_options)
                        elif event.key in [pygame.K_DOWN, pygame.K_s]:
                            self.menu_selection = (self.menu_selection + 1) % len(self.menu_options)
                        elif event.key == pygame.K_RETURN:
                            self.process_selection(self.menu_options[self.menu_selection]['id'])
                    elif event.key == pygame.K_d: self.toggle_debug()
                    elif self.game_state in ["STAGE_CLEAR", "GAME_OVER", "VICTORY", "HOW_TO"]:
                        self.game_state = "MENU"

            self.handle_input()
            self.update()
            self.screen.fill(COLOR_BG)
            
            if self.game_state == "MENU":
                self.draw_modern_menu()
            elif self.game_state == "HOW_TO":
                self.draw_how_to()
            elif self.game_state == "SPLASH":
                self.draw_splash()
            else:
                self.game_map.draw(self.screen, self.frame_count)
                if self.player.active: self.player.draw(self.screen)
                
                boss_stats = (0, 0)
                for enemy in self.enemies:
                    enemy.draw(self.screen)
                    if enemy.tank_type == 'boss':
                        boss_stats = enemy.last_stats
                        if self.game_state == "BOSS_FIGHT": self.total_stats.append(boss_stats)
                
                for bullet in self.bullets: bullet.draw(self.screen)

                for y in range(GRID_SIZE):
                    for x in range(GRID_SIZE):
                        if self.game_map.grid[y][x] == FOREST:
                            pygame.draw.rect(self.screen, COLOR_FOREST, (x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE, TILE_SIZE))

                self.hud.draw(self.screen, self.player.lives, len(self.enemy_pool) + len(self.enemies), self.level, self.game_state, boss_stats)
                
                # Only show mobile controls if touch interaction is detected
                if self.is_mobile:
                    self.draw_mobile_controls()
            
            if self.debug_mode and self.game_state not in ["MENU", "SPLASH", "HOW_TO"]:
                self.draw_debug()

            pygame.display.flip()
            self.clock.tick(FPS)
            self.frame_count += 1
            await asyncio.sleep(0)

    def draw_how_to(self):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((10, 10, 20, 235))
        self.screen.blit(overlay, (0,0))
        
        font_l = pygame.font.SysFont(['Outfit', 'Segoe UI', 'Arial'], 48, bold=True)
        font_m = pygame.font.SysFont(['Outfit', 'Segoe UI', 'Arial'], 24)
        font_s = pygame.font.SysFont(['Arial'], 18)
        
        title = font_l.render("HOW TO PLAY", True, COLOR_ACCENT)
        self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 80)))
        
        y = 180
        if self.is_mobile:
            controls = [
                ("VIRTUAL D-PAD", "Hold bottom-left area to move your tank"),
                ("FIRE BUTTON", "Tap the red circle (bottom-right) to shoot"),
                ("SELECTING", "Tap menu items directly to select them"),
                ("OBJECTIVE", "Destroy all enemies and protect the Eagle base!")
            ]
        else:
            controls = [
                ("WASD / ARROWS", "Use keys to move your tank in 4 directions"),
                ("SPACEBAR", "Press to fire high-velocity shells"),
                ("D-KEY", "Toggle AI debug pathfinding lines"),
                ("OBJECTIVE", "Destroy all enemies and protect the Eagle base!")
            ]
            
        for title_text, desc_text in controls:
            t_surf = font_m.render(title_text, True, COLOR_SELECTED)
            d_surf = font_s.render(desc_text, True, (160, 160, 180))
            self.screen.blit(t_surf, (SCREEN_WIDTH//2 - 180, y))
            self.screen.blit(d_surf, (SCREEN_WIDTH//2 - 180, y + 30))
            y += 80
            
        prompt = font_s.render("TAP ANYWHERE OR PRESS ANY KEY TO GO BACK", True, COLOR_ACCENT)
        self.screen.blit(prompt, prompt.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT - 60)))

    def draw_mobile_controls(self):
        for direction, rect in self.dpad_rects.items():
            # Glowing Glass effect
            s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            pygame.draw.rect(s, (30, 30, 50, 120), (0, 0, rect.width, rect.height), border_radius=15)
            pygame.draw.rect(s, (0, 255, 200, 100), (0, 0, rect.width, rect.height), 2, border_radius=15)
            
            center = (rect.width//2, rect.height//2)
            arrow_color = (255, 255, 255, 200)
            if direction == UP: pygame.draw.polygon(s, arrow_color, [(center[0], 15), (20, 45), (40, 45)])
            elif direction == DOWN: pygame.draw.polygon(s, arrow_color, [(center[0], 45), (20, 15), (40, 15)])
            elif direction == LEFT: pygame.draw.polygon(s, arrow_color, [(15, center[1]), (45, 20), (45, 40)])
            elif direction == RIGHT: pygame.draw.polygon(s, arrow_color, [(45, center[1]), (15, 20), (15, 40)])
            self.screen.blit(s, rect)

        s = pygame.Surface((self.fire_rect.width, self.fire_rect.height), pygame.SRCALPHA)
        pygame.draw.circle(s, (255, 60, 80, 130), (40, 40), 40)
        pygame.draw.circle(s, (255, 255, 255, 100), (40, 40), 40, 2)
        pygame.draw.circle(s, (255, 255, 255, 150), (40, 40), 15, 2)
        self.screen.blit(s, self.fire_rect)

    def draw_modern_menu(self):
        # Draw tech-background grid
        for i in range(0, SCREEN_WIDTH, 40): pygame.draw.line(self.screen, (15, 15, 25), (i, 0), (i, SCREEN_HEIGHT))
        for i in range(0, SCREEN_HEIGHT, 40): pygame.draw.line(self.screen, (15, 15, 25), (0, i), (SCREEN_WIDTH, i))

        # Title: BATTLE CITY (Military Logo Style)
        font_large = pygame.font.SysFont(['Outfit', 'Segoe UI', 'Arial'], 80, bold=True)
        title_surf = font_large.render("BATTLE CITY", True, (255, 255, 255))
        title_rect = title_surf.get_rect(center=(SCREEN_WIDTH // 2, 100))
        # Subtle Glitch/Offset Shadow
        shadow = font_large.render("BATTLE CITY", True, (0, 255, 200, 100))
        self.screen.blit(shadow, title_rect.move(3, 2))
        self.screen.blit(title_surf, title_rect)

        font_small = pygame.font.SysFont(['Outfit', 'Segoe UI', 'Arial'], 18, bold=True)
        subtitle = font_small.render("A D V A N C E D   C O M B A T   O S", True, COLOR_ACCENT)
        self.screen.blit(subtitle, subtitle.get_rect(center=(SCREEN_WIDTH // 2, 160)))

        # Card Menu
        card_w, card_h = 420, 80
        start_y = 220
        for i, opt in enumerate(self.menu_options):
            is_selected = (i == self.menu_selection)
            y_pos = start_y + i * (card_h + 15)
            rect = pygame.Rect(SCREEN_WIDTH // 2 - card_w // 2, y_pos, card_w, card_h)
            
            # Card Background
            bg_color = (25, 25, 35) if not is_selected else (35, 35, 50)
            pygame.draw.rect(self.screen, bg_color, rect, border_radius=8)
            
            # Selection Targeting Brackets (Static)
            if is_selected:
                b_len = 20
                b_thick = 3
                # Top Left
                pygame.draw.line(self.screen, COLOR_ACCENT, (rect.x-5, rect.y-5), (rect.x-5+b_len, rect.y-5), b_thick)
                pygame.draw.line(self.screen, COLOR_ACCENT, (rect.x-5, rect.y-5), (rect.x-5, rect.y-5+b_len), b_thick)
                # Bottom Right
                pygame.draw.line(self.screen, COLOR_ACCENT, (rect.right+5, rect.bottom+5), (rect.right+5-b_len, rect.bottom+5), b_thick)
                pygame.draw.line(self.screen, COLOR_ACCENT, (rect.right+5, rect.bottom+5), (rect.right+5, rect.bottom+5-b_len), b_thick)
                
                # Active Status Bar
                pygame.draw.rect(self.screen, COLOR_ACCENT, (rect.x, rect.y, 5, rect.h), border_radius=8)
            else:
                pygame.draw.rect(self.screen, (50, 50, 70), rect, 1, border_radius=8)

            # Icon & Text
            pygame.draw.circle(self.screen, opt['color'], (rect.x + 40, rect.centery), 8)
            name_surf = font_small.render(opt['name'], True, (255, 255, 255) if is_selected else (180, 180, 200))
            self.screen.blit(name_surf, (rect.x + 70, rect.y + 18))
            
            desc_font = pygame.font.SysFont(['Arial'], 14)
            desc_surf = desc_font.render(opt['desc'], True, (120, 120, 140))
            self.screen.blit(desc_surf, (rect.x + 70, rect.y + 45))
            
            # Tech Decoration (Status Indicators)
            status_font = pygame.font.SysFont(['JetBrains Mono', 'Consolas', 'monospace'], 10)
            status_text = "READY" if not is_selected else "ACTIVE"
            status_surf = status_font.render(status_text, True, COLOR_ACCENT if is_selected else (80, 80, 100))
            self.screen.blit(status_surf, (rect.right - 60, rect.y + 15))

        # Bottom Hint
        hint_font = pygame.font.SysFont(['Arial'], 12)
        hint_text = "SYSTEM STATUS: OPTIMAL • ALL NEURAL LINKS ACTIVE"
        hint_surf = hint_font.render(hint_text, True, (80, 80, 100))
        self.screen.blit(hint_surf, hint_surf.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 30)))

    def draw_splash(self):
        self.screen.fill(COLOR_BG)
        font = pygame.font.SysFont(['Outfit', 'Segoe UI', 'Arial'], 64, bold=True)
        text = f"STAGE {self.level}" if self.level != 'B' else "ULTIMATE BOSS"
        surf = font.render(text, True, COLOR_SELECTED)
        rect = surf.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        bar_w = 300
        progress = (STAGE_SPLASH_TIME - self.splash_timer) / STAGE_SPLASH_TIME
        pygame.draw.rect(self.screen, COLOR_CARD_BG, (SCREEN_WIDTH//2 - bar_w//2, SCREEN_HEIGHT//2 + 60, bar_w, 10), border_radius=5)
        pygame.draw.rect(self.screen, COLOR_ACCENT, (SCREEN_WIDTH//2 - bar_w//2, SCREEN_HEIGHT//2 + 60, int(bar_w * progress), 10), border_radius=5)
        self.screen.blit(surf, rect)

    def draw_debug(self):
        font = pygame.font.SysFont('Arial', 14)
        mx, my = pygame.mouse.get_pos()
        tx, ty = mx // TILE_SIZE, my // TILE_SIZE
        if tx < GRID_SIZE and ty < GRID_SIZE:
            txt = font.render(f"Tile: ({tx}, {ty})", True, (255, 255, 0))
            self.screen.blit(txt, (mx + 10, my + 10))

async def main():
    game = Game()
    await game.run()

if __name__ == "__main__":
    asyncio.run(main())
